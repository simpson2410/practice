import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bt3',
  templateUrl: './bt3.component.html',
  styleUrls: ['./bt3.component.scss']
})
export class BT3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
