import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bt1',
  templateUrl: './bt1.component.html',
  styleUrls: ['./bt1.component.scss']
})
export class BT1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
