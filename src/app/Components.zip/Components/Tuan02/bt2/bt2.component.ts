import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bt2',
  templateUrl: './bt2.component.html',
  styleUrls: ['./bt2.component.scss']
})
export class BT2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
